﻿internal interface paralizar
{
    void paralizado();
    void deparalize();
}